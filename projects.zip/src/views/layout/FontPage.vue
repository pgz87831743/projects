<template>
  <div>
    <el-affix >
      <el-menu
          class="el-menu-demo"
          mode="horizontal"
          :ellipsis="false"
          router
          :default-active="$route.fullPath"
      >
        <el-menu-item ><div style="color: green;font-size: 20px;font-weight: bold">高校数字资源共享平台</div></el-menu-item>
        <el-menu-item index="/IndexPage">首页</el-menu-item>
        <el-menu-item index="/SearchResource">我要找资源</el-menu-item>
        <el-menu-item index="/PublishResource">我要发布资源</el-menu-item>
        <div class="flex-grow" />
        <el-sub-menu index="2-4">
          <template #title>
            <el-avatar :src="user.avatar"></el-avatar>
          </template>
          <el-menu-item index="/PersonalCenter">我的主页</el-menu-item>
          <el-menu-item v-if="authShow('ADMIN')"  index="/UserManagement">后台管理</el-menu-item>
          <el-menu-item index="/login" @click="logout">退出登录</el-menu-item>

        </el-sub-menu>

      </el-menu>
    </el-affix>
    <router-view></router-view>
  </div>
</template>

<script>
import {logout, systemCurrentUser} from "@/api/api";
import {removeItem} from "@/utils/storage";
import router from "@/router";
import {authShow} from "@/utils/authutil";

export default {
  name: "FontPage",
  data(){
    return{
      user: {}
    }
  },
  methods:{
    authShow,
    userQuery() {
      systemCurrentUser()
          .then((resp) => {
            this.user = resp.data.data
          })
    },

    logout() {
      logout().then(() => {
        removeItem("TOKEN_INFO_KEY")
        router.push({path: '/login'})
      })
    }
  },
  mounted() {
    this.userQuery()
  }
}
</script>

<style scoped>
.flex-grow {
  flex-grow: 1;
}
</style>