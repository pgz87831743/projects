<template>
<div>
  资源管理
</div>
</template>

<script>
export default {
  name: "ResourcesManagement"
}
</script>

<style scoped lang="scss">

</style>